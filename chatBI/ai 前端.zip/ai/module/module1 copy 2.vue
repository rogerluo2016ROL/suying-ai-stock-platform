<template>
    <div>
        <div class="icoHi">
            <componentsHistory @getLiShi="getLiShi" @newAdd='newAdd'></componentsHistory>

        </div>
        <div class="top-text" v-if="dataText.length == 0"
            @click="isShowPicture(3, { id: 14, text: '你好', AItext: '我不好' })">
            <h2> 你好，有问题尽管问！ </h2>

            <span class="top-state">仅限于<span class="top-state2">应用内的指标分析</span>哟</span>
        </div>

        <div v-show="dataText.length > 0" class="content" id="yourElementId" ref="container" @scroll="handleScroll">

            <div v-for="(item, index) in dataText">
                <el-row>
                    <div class="my-content">
                        <span class="content-span"> {{ item.text }} </span>
                    </div>
                </el-row>
                <el-row>
                    <div style="position: relative;right: 10px;top: 3px;">
                        <img class="ml-2 " style="float: right;" :src="require('@/assets/images/wel/bianji.svg')" alt=""
                            @click='setText(item.text)'>
                        <img class="ml-2 " style="float: right;" :src="require('@/assets/images/wel/fuzhi.svg')" alt=""
                            @click='getText(item.text)'>
                    </div>
                </el-row>
                <el-row>
                    <div class="ai-content">
                        <!-- <span class="content-span" v-html="item.AItext"></span> -->
                        <span class="content-span">
                            <el-collapse v-model="index" @change="handleChange">

                                <el-collapse-item :name="index">

                                    <template slot="title">
                                        <img style="width: 15px;height: 15px;"
                                            :src="require('@/assets/images/wel/huida.svg')" alt="">
                                        <span style="margin-left: 5px;font-size: 17px;font-weight: 600;"> 回答</span>
                                        <span class="ml-3 mr-1" style="font-size: 15px;">{{ item.reflectState ? '思考过程' :
                                            '终止思考' }} </span>
                                        <span style="color: #999;">
                                            <i class="el-icon-loading " v-if="item.reflectOnLog"></i>
                                            <span v-if="!item.reflectOnLog">{{ '(' + item.time + '秒)' }}</span>
                                        </span>
                                    </template>
                                    <div style="font-size: 12px;color: #999;">

                                        <!-- <Markdown ref="childRef" :key="index" :content="item.reflectOn" /> -->
                                        <el-steps direction="vertical" :active="item.active" finish-status="success"
                                            :key="index">
                                            <el-step title="数据权限检索" :key="index"
                                                :class="item.reflectOn == '权限校验通过' ? '' : item.reflectOn == '操作成功' ? '' : item.reflectOn == '' ? '' : 'bor-cor'">
                                                <template slot="icon">
                                                    <i class="el-icon-loading" v-show="item.reflectOn == ''"></i>
                                                    <i class="el-icon-check" v-show="item.reflectOn == '权限校验通过'"
                                                        style="color: gold;"></i>
                                                    <i class="el-icon-close" v-show="item.reflectOn != ''"></i>
                                                </template>


                                                <div slot="title" class="title-text">
                                                    数据权限检索</div>
                                                <div slot="description" style="color: #585353;">
                                                    <div class="mt-1 mb-2">{{ item.reflectOn }} </div>
                                                    <!-- <Markdown ref="childRef" :key="index" :content="item.reflectOn" /> -->
                                                </div>
                                            </el-step>
                                            <el-step title="知识检索" v-show="item.active >= 1">
                                                <template slot="icon">
                                                    <i class="el-icon-loading"></i>

                                                </template>
                                                <div slot="title" class="title-text">
                                                    知识检索</div>
                                                <div slot="description" style="color: #585353;">
                                                    <div class="mt-1 mb-2">已完成</div>
                                                    <!-- <Markdown ref="childRef" :key="index" content="已完成" /> -->
                                                </div>


                                            </el-step>
                                            <el-step title="关键数据检索" v-show="item.active >= 2">
                                                <template slot="icon">
                                                    <i class="el-icon-loading"></i>
                                                </template>
                                                <div slot="title" class="title-text">
                                                    关键数据检索</div>
                                                <div slot="description" style="color: #585353;">
                                                    <div class="mt-1 mb-2" v-if="item.active >= 3">已完成</div>
                                                    <!-- <Markdown v-if="item.active >= 3" ref="childRef"
                                                        :key="item.reflectOn3" content="已完成" /> -->
                                                </div>
                                            </el-step>
                                            <el-step title="生成回答" v-show="item.active >= 3">
                                                <template slot="icon">
                                                    <i class="el-icon-loading"></i>
                                                </template>
                                                <div slot="title" class="title-text">
                                                    生成回答</div>
                                                <div slot="description" style="color: #585353;">
                                                    <div class="mt-1">{{ item.reflectOn4 }}</div>
                                                    <!-- <Markdown ref="childRef" :key="item.reflectOn3"
                                                        v-if="item.active >= 4" content="已完成" /> -->
                                                </div>
                                            </el-step>
                                        </el-steps>
                                    </div>
                                </el-collapse-item>

                            </el-collapse>
                            <Markdown ref="childRef" :key="index" :content="item.AItext" />

                        </span>
                    </div>

                </el-row>

                <div class="evaluate" v-if="item.isYou && !Interrupt"><!-- v-if="item.isYou && !Interrupt" -->
                    <img v-if="!isActivate" :src="require('@/assets/images/wel/zan.svg')" alt=""
                        @click='isShowPicture(1)'>
                    <img v-if="isActivate" :src="require('@/assets/images/wel/zan2.svg')" alt=""
                        @click='isShowPicture(2)'>
                    <i style="margin: 0px 5px;"></i>
                    <img v-if="!isLove" :src="require('@/assets/images/wel/noLove.svg')" alt=""
                        @click='isShowPicture(3, item)'>
                    <img v-if="isLove" :src="require('@/assets/images/wel/noLove2.svg')" alt=""
                        @click='isShowPicture(4)'>
                    <img class="ml-2" :src="require('@/assets/images/wel/new.svg')" alt=""
                        @click='getNewApi(item.text)'>



                </div>

            </div>

        </div>
        <div class="search-box" ref="myElement" :style="{ bottom: botVlu }">
            <template v-if="!shutoff && restaurants.length > 0 && input != ''">
                <div class="box-tishi">
                    <ul>
                        <li v-for="itemList in restaurants" @click="handleSelect(itemList.value)">{{ itemList.value }}
                        </li>

                    </ul>
                </div>
                <div>
                    <i class="el-icon-caret-bottom"></i>
                </div>
            </template>


            <div v-if="!shutoff" class="box">

                <div>
                    <!-- <span class="box-text">点这里,你可以开始提问了</span> -->
                    <el-input v-model="input" style="font-size: 15px;" placeholder="点这里,你可以开始提问了"
                        @keyup.enter.native="getSplitWordsAndPermission" @focus='incomingTrunk(false)'
                        @blur="incomingTrunk2(true)" @input="querySearch"></el-input>

                    <!-- <el-autocomplete @keyup.enter.native="getSplitWordsAndPermission" @focus='incomingTrunk(false)'
                        @blur="incomingTrunk2(true)" class="inline-input" v-model="input"
                        :fetch-suggestions="querySearch" placeholder="请输入内容" :trigger-on-focus="false" placement="top"
                        @select="handleSelect"></el-autocomplete> -->
                </div>
                <div class="box-bottom">
                    <div class="left">
                        <!-- <span :class="isShow ? 'span-text' : 'span-text2'" @click="ApiDepth"> (R1)深度思考</span> -->
                    </div>
                    <div class="right">
                        <!-- <img :src="require('@/assets/images/wel/yuyin.svg')" alt=""> -->

                        <!-- <i
                            style="width: 0.5px;height: 5px;border: 1px solid #c5c7ca;margin: 8px;position: relative;bottom: 6px;"></i> -->
                        <img :src="require('@/assets/images/wel/fas.svg')" alt="" @click="getSplitWordsAndPermission">


                        <!-- <div ></div> -->

                    </div>
                </div>
            </div>
            <div v-else style="margin-left: 45%;text-align: left;" class="mb-2">
                <span @click="stopApi">
                    <img style="position: relative;top: 4px;" :src="require('@/assets/images/wel/tingzhi.svg')" alt="">
                    <span style="color: #000;font-size: 17px; font-weight: 600;">
                        停止</span>
                </span>
            </div>
        </div>

        <van-popup v-model="showPopup" position="bottom" :style="{ height: '100%' }">
            <Feedback @close="showPopup = false" :row="row"></Feedback>
        </van-popup>




    </div>
</template>

<script>
import TopTimeSelect from "@/components/tool/TopTimeSelect";
import componentsHistory from "./componentsHistory.vue";
import Feedback from "./feedback.vue";
import Markdown from './Markdown.vue';
import { splitWordsAndPermission, gethistory, questionKey } from "@/api/home/home.js";
import { postFormNoLoadAction6 } from "@/api/manage.js";
import { createdSession } from "@/api/home/home.js";
import { clearHttpRequestingList } from "@/utils/util.js";
import { Toast } from 'vant';

export default {

    inject: ["main"],
    components: { componentsHistory, Markdown, Feedback },
    data() {
        return {
            row: {},
            dataList: [
                {
                    text: '广汽传祺3月终端销量趋势分析'
                },
                {
                    text: '广汽集团终端销量分析'
                },
                {
                    text: '集团3月竞品分析'
                },
                {
                    text: '2024年第一季度财务报表'
                },
                {
                    text: '国际今年销量情况'
                },
            ],
            interval: '',
            interval2: '',
            interval3: '',
            input: '',
            showPopup: false,
            isShow: false,
            isActivate: false,
            isLove: false,
            dataText: [],
            sessionId: '',
            agentId: '',
            streamData: '',
            streamController: {},
            loading: false,
            responseText: '',
            // markdownContent: '',
            Interrupt: false,//图片点赞状态
            shutoff: false,
            activeNames: ['1'],
            strResult: '',
            startTime: null,//开始计时
            controller: null,
            container: null,
            autoScroll: true,
            autoScrollEnabled: true,
            observer: null,
            textToCopy: '',
            scrollDebounce: null,
            sessionIdKey: '',
            agentIdKey: '',

            userInfo: JSON.parse(sessionStorage.getItem('userInfo')) || { UserId: '15205009333', name: 'zhou' },
            botVlu: '1.33333rem',
            restaurants: [],
            markdownContent: "<think>问题: 埃安品牌2025年1月的销售情况\n\n### 执行结果:\n\n```sql\nSELECT brand_name AS `品牌`,\n yearmonth AS `年月`,\n ROUND(SUM(wholesale_qty),2) AS `批发销量`,\n ROUND(SUM(terminal_qty),2) AS `终端销量`\nFROM cockpit_plan_report_v3\nWHERE yearmonth = '202501'\n AND org_name = '广汽埃安'\n AND brand_name = 'エ安'\nGROUP BY brand_name, yearmonth;\n```\n\n| 品牌 | 年月 | 批发销量 | 终端销量 |\n|:-------|-------:|-----------:|------------:|\n| エ安 | 202501 | 6019.00 | 12664.00 |\n\n### 分析总结:\n从2025年1月销售数据显示：\n1. **渠道差异显著**：终端零售量（12,664台）是批发量（6,019台）的2.1倍；\n2. **去库存特征明显**：当月实际交付量为进货量的两倍以上；\n3. **市场表现强劲**：单月超12,600台的零售成绩显示出较强的市场消化能力；\n4. **渠道网络优势**：较高的零售转化率表明经销商体系具备良好的销售执行力。\n\n（注：因仅存</think>\n\n### 问题: 埃安品牌2025年1月的销售情况\n\n### 执行结果:\n\n```sql\nSELECT brand_name AS `品牌`,\n yearmonth AS `年月`,\n ROUND(SUM(wholesale_qty),2) AS `批发销量`,\n ROUND(SUM(terminal_qty),2) AS `终端销量`\nFROM cockpit_plan_report_v3\nWHERE yearmonth = '202501'\n AND org_name = '广汽埃安'\n AND brand_name = 'エ安'\nGROUP BY brand_name, yearmonth;\n```\n\n| 品牌 | 年月 | 批发销量 | 终端销量 |\n|:-------|-------:|-----------:|------------:|\n| エ安 | 202501 | 6019.00 | 12664.00 |\n\n### 分析总结:\n从2025年1月销售数据显示：\n1. **渠道差异显著**：终端零售量（12,664台）是批发量（6,019台）的2.1倍；\n2. **去库存特征明显**：当月实际交付量为进货量的两倍以上；\n3. **市场表现强劲**：单月超12,600台的零售成绩显示出较强的市场消化能力；\n4. **渠道网络优势**：较高的零售转化率表明经销商体系具备良好的销售执行力。\n\n（注：因仅存在单条记录未触发汇总计算）"
        }
    },

    watch: {

    },


    mounted() {
        this.handleEnter()
        this.container = document.getElementById('yourElementId');
        this.getLiShi()



        if (this.$route.query.value) { //点击热门话题进来
            this.input = this.$route.query.value
            this.getSplitWordsAndPermission()
        }
    },
    computed: {
        formattedResponse() {
            return this.responseText.replace(/\n/g, '<br>');
        },

    },
    methods: {

        lapili(index) {
            let clsName = ''
            if (index == 0) clsName = 'target'
            if (index == 1) clsName = 'target2'
            if (index == 2) clsName = 'target3'
            return clsName
        },
        ApiDepth() {
            this.isShow = !this.isShow
        },
        getSplitWordsAndPermission() {// 获取拆分后的单词和权限


            let obj = {
                "question": this.input,
                "sessionUuid": this.sessionIdKey,
                "userId": this.userInfo.UserId,
                "userName": this.userInfo.name,

            }
            if (this.input == '') return

            this.dataText.push({
                text: this.input,
                AItext: '',
                reflectOn: '', //思考文本
                reflectOn2: '', //思考文本2
                reflectOn3: '', //思考文本2
                reflectOn4: '', //思考文本2
                AItextLog: false, //AI文本
                active: 0,//步骤
                reflectOnLog: true, //思考圈圈
                time: 0,
                modelState: false,//模型状态
                reflectState: true,//思考状态

            })

            this.shutoff = true
            this.Interrupt = true

            window.scrollTo(0, document.body.scrollHeight); //滚动到底部
            splitWordsAndPermission(obj).then(res => {

                if (res.code == 200) {
                    this.dataText[this.dataText.length - 1].id = res.data.id
                    this.dataText[this.dataText.length - 1].reflectOn = res.msg
                    this.dataText[this.dataText.length - 1].active = 1

                    this.sendApi(res.data.id)
                } else {
                    this.stopApi()
                    this.dataText[this.dataText.length - 1].reflectOn = res.msg
                }
            })




        },
        sendApi(id) {//发送功能

            this.startTime = performance.now();
            let obj = {
                "question": this.input,
                "sessionId": this.sessionId,
                "agentId": this.agentId,
                "userId": this.userInfo.UserId,
                "userName": this.userInfo.name,
                'id': id
            }

            let arr = ''
            // 取消之前的请求
            if (this.controller) {
                this.controller.abort();
            }

            this.controller = new AbortController();

            let strArr = []
            window.scrollTo(0, document.body.scrollHeight); //滚动到底部

            // postFormNoLoadAction6(
            //     `/gac/ragflow/ai/send-stream`,
            //     obj,
            //     async (res) => {

            //         const { code, msg } = JSON.parse(res.data)

            //         arr += msg

            //         let result = arr.split('<model>')[1];
            //         let result2 = arr.split('</know>')[1];
            //         let result3 = arr.split('<know>')[1];

            //         if (result) {

            //             if (result.indexOf('</model>') != -1) {
            //                 let str = '<model>' + result.split('</know>')[0]

            //                 const regex = /<model>(.*?)<\/model>/;
            //                 str = str.match(regex)[1];
            //                 this.dataText[this.dataText.length - 1].reflectOn2 = str
            //                 this.dataText[this.dataText.length - 1].active = 2



            //             }
            //         }
            //         if (result3) {
            //             if (result.indexOf('</know>') != -1) {

            //                 let str = result.split('</know>')[0]
            //                 str = str.split("<know>")[1]
            //                 console.log("cccccccccc", str)
            //                 // const regex = /<know>(.*?)<\/know>/;
            //                 // str = str.match(regex)[1];
            //                 this.dataText[this.dataText.length - 1].reflectOn3 = str
            //                 this.dataText[this.dataText.length - 1].active = 3



            //             }
            //         }
            //         if (result2) {
            //             const endTime = performance.now();
            //             // this.dataText[this.dataText.length - 1].time = ((endTime - this.startTime) / 1000).toFixed(2)

            //             this.dataText[this.dataText.length - 1].reflectOnLog = false
            //             this.dataText[this.dataText.length - 1].AItext = result2

            //         }

            //         if (arr.includes('</think>')) {//思考时间
            //             strArr.push({
            //                 time: performance.now()
            //             })

            //             this.dataText[this.dataText.length - 1].time = ((strArr[0].time - this.startTime) / 1000).toFixed(2)

            //         }
            //         if (code == '500') {
            //             this.dataText[this.dataText.length - 1].reflectOn = msg
            //         }
            //         setTimeout(() => {
            //             window.scrollTo(0, document.body.scrollHeight); //滚动到底部
            //         }, 1000);

            //     },
            //     { signal: this.controller.signal }, // 添加AbortSignal
            //     (okres) => {  //结束回调
            //         this.shutoff = false
            //         this.Interrupt = false
            //         console.log(arr, "okres");
            //     }
            // )

            let countdown = 80; // 设置倒计时时间，单位为秒
            const intervalStop = setInterval(() => {
                // console.log(`剩余时间：${countdown}秒`);
                countdown--;

                if (countdown < 0) {
                    clearInterval(intervalStop);
                    this.dataText[this.dataText.length - 1].reflectOn4 = '当前使用人数较多，请重新加载页面后再次尝试'
                    this.cancelRequest()
                    this.stopApi()
                    // console.log("倒计时结束");
                }
            }, 1000);

            postFormNoLoadAction6(
                // `/gac/ragflow/ai/send-stream`,
                `/gac/ragflow/ai/chat-messages/test`,
                obj,
                async (res) => {

                    const { code, msg } = JSON.parse(res.data)

                    arr += msg



                    if (arr.includes("知识检索")) {
                        this.dataText[this.dataText.length - 1].active = 2
                    }
                    if (arr.includes("输出使用表名")) {
                        this.dataText[this.dataText.length - 1].active = 3
                    }
                    if (arr.includes("模板转换")) {
                        this.dataText[this.dataText.length - 1].reflectOn4 = '已完成'
                        this.dataText[this.dataText.length - 1].active = 4
                    }

                    if (arr.includes('<model>')) {
                        clearInterval(intervalStop);
                    }



                },
                { signal: this.controller.signal }, // 添加AbortSignal
                (okres) => {  //结束回调
                    let match = arr.match(/<model>([\s\S]*?)<\/model>/);
                    let result = match ? match[1].trim() : '';

                    let match2 = arr.match(/<know>([\s\S]*?)<\/know>/);
                    let result2 = match2 ? match2[1].trim() : '';
                    result2 = result2.replace(/-/g, "\n-");

                    let result3 = arr.match(/<\/know>([\s\S]*)/);
                    if (result3) {
                        result3 = result3[1].trim();
                        result3 = result3.replace(/ /g, ''); //  修复表格解析错位
                        result3 = result3.split('三、SQL代码')[0]

                        // result3 = result3.replace('</ans>', ''); //去掉最后一个</ans>
                    }
                    this.dataText[this.dataText.length - 1].time = ((performance.now() - this.startTime) / 1000).toFixed(2)
                    this.typeWriter1(result, this.dataText.length - 1, 40, result2, result3)
                    console.log(arr, "okres");
                }
            )
            // this.typeWriterReflectOn(this.reflectOnApi(this.markdownContent), this.dataText.length - 1, 40)
            // this.typeWriter(this.markdownContent, this.dataText.length - 1, 40)
            this.input = ''
            this.isActivate = false
            this.isLove = false
            // window.scrollTo(0, document.body.scrollHeight); //滚动到底部


            if (this.dataText) { //点赞
                this.dataText.forEach((item, index) => {
                    if (index == this.dataText.length - 1) {
                        item.isYou = true
                    } else {
                        item.isYou = false
                    }
                })
            }







        },

        scrollToBottom() {
            const container = this.$refs.container;
            container.scrollTop = container.scrollHeight;
            console.log('滚动到底部', container);
        },
        setupObserver() {
            this.observer = new IntersectionObserver((entries) => {
                // 当底部标记不可见时，说明用户手动滚动了
                this.autoScrollEnabled = entries[0].isIntersecting;
            }, {
                root: this.$refs.container,
                threshold: 0.1
            });

            this.observer.observe(this.$refs.bottomMarker);
        },
        typeWriter(text, elementId, speed) {
            let i = 0;
            const element = this.dataText[elementId].AItext
            const interval = setInterval(() => {
                if (i < text.length) {
                    this.dataText[elementId].AItext += text.charAt(i);
                    i++;
                } else {
                    console.log('完成输出');
                    this.dataText[elementId].AItextLog = true

                    this.shutoff = false
                    clearInterval(interval); // 完成输出后清除间隔
                }
            }, speed);
        },
        typeWriterReflectOn(text, elementId, speed, stop) { //思考输出

            let i = 0;
            const element = this.dataText[elementId].reflectOn
            this.interval = setInterval(() => {
                if (i < text.length) {
                    this.dataText[elementId].reflectOn += text.charAt(i);
                    i++;
                } else {
                    this.typeWriter(this.strResult, this.dataText.length - 1, 40)
                    this.dataText[this.dataText.length - 1].reflectOnLog = false
                    const endTime = performance.now();
                    this.dataText[this.dataText.length - 1].time = ((endTime - this.startTime) / 1000).toFixed(2)

                    clearInterval(this.interval); // 完成输出后清除间隔
                }
            }, speed);


        },
        typeWriter1(text, elementId, speed, text2, text3) {
            let i = 0;

            const interval = setInterval(() => {
                if (i < text.length) {
                    this.dataText[elementId].reflectOn2 += text.charAt(i);
                    i++;
                } else {
                    // console.log('完成输出');

                    // this.dataText[elementId].active = 2
                    this.typeWriter2(text2, this.dataText.length - 1, 40, text3)

                    window.scrollTo(0, document.body.scrollHeight); //滚动到底部

                    clearInterval(interval); // 完成输出后清除间隔
                }
            }, speed);
        },
        typeWriter2(text, elementId, speed, text3) {
            let i = 0;

            this.interval2 = setInterval(() => {
                if (i < text.length) {
                    this.dataText[elementId].reflectOn3 += text.charAt(i);
                    i++;
                } else {
                    // console.log('完成输出');

                    // this.dataText[elementId].active = 3
                    this.typeWriter3(text3, this.dataText.length - 1, 20)

                    clearInterval(this.interval2); // 完成输出后清除间隔
                }
            }, speed);
        },
        typeWriter3(text, elementId, speed) {
            let i = 0;

            this.interval3 = setInterval(() => {
                if (i < text.length) {
                    this.dataText[elementId].AItext += text.charAt(i);
                    setTimeout(() => {
                        window.scrollTo(0, document.body.scrollHeight); //滚动到底部
                    }, 1000);
                    i++;
                } else {
                    // console.log('完成输出');

                    this.dataText[elementId].reflectOnLog = false
                    this.shutoff = false
                    this.Interrupt = false

                    clearInterval(this.interval3); // 完成输出后清除间隔
                }
            }, speed);
        },
        reflectOnApi(strValue) { //截取思考中的字符串
            let htmlString = strValue;
            let startTag = '<think>';
            let endTag = '</think>';
            let startIndex = htmlString.indexOf(startTag) + startTag.length;
            let endIndex = htmlString.indexOf(endTag);
            let content = htmlString.substring(startIndex, endIndex); // "你好呀"
            return content
        },
        isShowPicture(val, item) {
            if (val == 1) {
                this.isActivate = true
                this.isLove = false
            } else if (val == 2) {
                this.isActivate = false
            } else if (val == 3) {
                this.isLove = true
                this.isActivate = false
                this.showPopup = true
                this.row = item
            } else if (val == 4) {
                this.isLove = false
            }
        },
        handleChange(val) {
            console.log(val);

        },
        handleEnter() {

            this.sessionId = this.$route.query.sessionId
            this.agentId = this.$route.query.agentId
            this.sessionIdKey = this.$route.query.sessionIdKey
            this.agentIdKey = this.$route.query.agentIdKey


        },
        async handleSubmit() {
            if (this.loading) {
                this.cancelRequest();
                return;
            }

            if (!this.userInput.trim()) return;

            this.loading = true;
            this.responseText = '';

            // 使用封装的流式请求方法
            const { promise, cancel } = postStreamAction('/ai-stream', {
                prompt: this.userInput
            }, {
                onMessage: (data) => {
                    this.responseText += data.choices?.[0]?.delta?.content || '';
                    this.$nextTick(() => {
                        this.$refs.responseArea.scrollTop = this.$refs.responseArea.scrollHeight;
                    });
                },
                onDone: () => {
                    this.loading = false;
                },
                onError: (error) => {
                    this.responseText += `\n请求失败: ${error.message}`;
                    this.loading = false;
                }
            });

            this.streamController = { cancel };
            await promise;
        },
        getNewApi(textValue) {
            this.input = textValue
            this.getSplitWordsAndPermission()
        },

        async getText(item) {//复制文本
            this.textToCopy = item
            try {
                if (navigator.clipboard) {
                    await navigator.clipboard.writeText(this.textToCopy)
                } else {
                    this.fallbackCopyText()
                }
                this.showToast('复制成功')
            } catch (err) {
                console.error('复制失败:', err)
                this.showToast('复制失败，请手动复制')
            }
        },
        fallbackCopyText() {
            const textarea = document.createElement('textarea')
            textarea.value = this.textToCopy
            textarea.style.position = 'fixed'
            document.body.appendChild(textarea)
            textarea.select()

            try {
                document.execCommand('copy')
            } finally {
                document.body.removeChild(textarea)
            }
        },
        handleScroll() {

            // 使用防抖避免频繁触发
            clearTimeout(this.scrollDebounce);

            this.scrollDebounce = setTimeout(() => {
                const container = this.$refs.container;
                const { scrollTop, scrollHeight, clientHeight } = container;

                // 如果用户滚动到接近底部（小于100px），恢复自动滚动
                if (scrollHeight - (scrollTop + clientHeight) < 100) {
                    this.autoScroll = true;
                } else {
                    // 用户手动向上滚动，停止自动滚动
                    this.autoScroll = false;
                }
            }, 200);
        },
        showToast(message) {
            // 使用你喜欢的提示方式，如vant、mint-ui的toast或自定义实现
            Toast.success('复制成功');
        },
        setText(item) {//编辑文本
            this.input = item
        },
        cancelRequest() { //终止请求
            if (this.controller) {
                this.controller.abort();
                this.controller = null;
            }
        },
        stopApi() {
            this.shutoff = false
            this.dataText[this.dataText.length - 1].reflectOnLog = false
            this.dataText[this.dataText.length - 1].reflectState = false
            if (!this.dataText[this.dataText.length - 1].reflectOn2) {
                this.dataText[this.dataText.length - 1].modelState = true
            }

            this.input = ''
            clearInterval(this.interval);
            clearInterval(this.interval2);
            clearInterval(this.interval3);
            this.cancelRequest()
            clearHttpRequestingList() //数据校验停止

            console.log('停止',);
        },
        getLiShi(item) {  //获取历史记录
            let urlId = this.$route.query.sessionUuid


            if (item) {
                let obj = {
                    sessionUuid: item,
                    userId: this.userInfo.UserId,
                }
                gethistory(obj).then(res => {
                    this.dataText = []
                    let dataArray = res.data

                    dataArray.forEach((item, index) => {
                        let next = 0
                        let text = '权限校验通过'
                        if (item.answer == null) {
                            item.answer = "<model>\nQwen3-32B\n</model><know></know></ans>"
                            text = '权限校验不通过或问题有误!!!'
                        } else {
                            next = 4
                        }


                        let str = item.answer.split("</know>")[1]

                        str = str.replace(/ /g, '')
                        str = str.replace('</ans>', ''); //去掉最后一个</ans>
                        str = str.split('三、SQL代码')[0]
                        console.log('历史记录', item.answer.match(/<know>([\s\S]*?)<\/know>/)?.[1].replace(/\n/g, ' \n '),);
                        this.dataText.push({
                            text: item.question,
                            AItext: str, //正文输出
                            reflectOn: text, //思考文本
                            AItextLog: false, //AI文本
                            reflectOn2: item.answer.match(/<model>([\s\S]*?)<\/model>/)?.[1], //思考文本2
                            reflectOn3: item.answer.match(/<know>([\s\S]*?)<\/know>/)?.[1].replace(/\n/g, '\n\n'), //思考文本2    
                            reflectOnLog: false, //思考圈圈
                            time: item.answerTime || 0,
                            active: next,//步骤
                            reflectState: true,//思考状态
                        })
                    })
                    this.dataText[this.dataText.length - 1].Interrupt = false
                    this.dataText[this.dataText.length - 1].isYou = true

                })
                console.log('历史记录1', item);

            } else if (urlId) {
                console.log('历史记录2', urlId);
                let obj = {
                    sessionUuid: urlId,
                    userId: this.userInfo.UserId,
                }
                gethistory(obj).then(res => {
                    this.dataText = []
                    let dataArray = res.data

                    dataArray.forEach((item, index) => {
                        let next = 0
                        let text = '权限校验通过'
                        if (item.answer == null) {
                            item.answer = "<model>\nQwen3-32B\n</model><know></know></ans>"
                            text = '权限校验不通过或问题有误!!!'
                        } else {
                            next = 4
                        }


                        let str = item.answer.split("</know>")[1]

                        str = str.replace(/ /g, '')
                        str = str.replace('</ans>', ''); //去掉最后一个</ans>
                        str = str.split('三、SQL代码')[0]
                        this.dataText.push({
                            text: item.question,
                            AItext: str, //正文输出
                            reflectOn: text, //思考文本
                            AItextLog: false, //AI文本
                            reflectOn2: item.answer.match(/<model>([\s\S]*?)<\/model>/)?.[1], //思考文本2
                            reflectOn3: item.answer.match(/<know>([\s\S]*?)<\/know>/)?.[1].replace(/\n/g, '\n\n'), //思考文本2
                            reflectOnLog: false, //思考圈圈
                            time: item.answerTime || 0,
                            active: next,//步骤
                            reflectState: true,//思考状态
                        })
                    })
                    this.dataText[this.dataText.length - 1].Interrupt = false
                    this.dataText[this.dataText.length - 1].isYou = true

                })



            }
        },
        incomingTrunk(val) {

            this.botVlu = '5px'
            this.$bus.emit('message', val)
        },
        incomingTrunk2(val) {
            setTimeout(() => {

                this.botVlu = '1.33333rem'
                this.$bus.emit('message', val)
            }, 100);

        },
        newAdd() {
            this.dataText = []
            console.log('newAdd');
        },
        handleSelect(item) {
            this.input = item
            this.getSplitWordsAndPermission()
            console.log(item, "555555555555");
        },
        querySearch(queryString, cb) {
            console.log('querySearch', queryString);

            questionKey({ question: queryString }).then(res => {
                if (res.code == 200) {
                    res.data.forEach(item => {
                        item.value = item.question
                        item.address = item.question
                    })
                    this.restaurants = res.data
                    // var restaurants = this.restaurants;
                    // var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
                    // 调用 callback 返回建议列表的数据
                    // cb(results);
                }

            })


        },
        createFilter(queryString) {
            return (restaurant) => {
                return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
            };
        },
    },
    beforeDestroy() {
        console.log('销毁');
        this.cancelRequest();

    }
}
</script>

<style scoped lang="less">
.icoHi {
    position: fixed;
    top: 0px;
    z-index: 999;
    background: #fff;
    width: 100%;
}

.top-text {
    margin-top: 24vh;
    text-align: center;

    h2 {
        margin-bottom: 5px;
        font-weight: 500;
    }

    .top-state {
        font-size: 14px;

        .top-state2 {
            color: #0881fa;
        }
    }
}

.content {
    margin-top: 60px;
    margin-bottom: 180px;

    // height: 560px;
    // overflow-y: auto;
    // border: 1px solid #eee;
    // padding: 10px;
    // scroll-behavior: smooth;
    /* 平滑滚动 */
}

.my-content {



    .content-span {
        font-size: 15px;
        float: right;
        max-width: 50%;
        background: #2563EB;
        color: #fff;
        padding: 8px;
        border-radius: 10px;
        // text-align: center;

        margin-left: auto;
        margin-right: 10px;
        margin-top: 10px;



    }




}

.ai-content {
    .content-span {
        font-size: 13px;
        float: left;
        max-width: 80%;
        background: #f7fafc;
        color: #585353;
        padding: 15px;
        border-radius: 10px;
        margin-right: auto;
        margin-left: 10px;
        margin-top: 10px;

        /deep/ .el-collapse-item__header {
            background-color: #f7fafc;
        }

        /deep/ .el-collapse-item__wrap {
            background-color: #f7fafc;
        }

        /deep/ .el-collapse {
            border-top: 0px;
        }

        /deep/ .el-step__icon {
            width: 0.51333rem;
            height: 0.51333rem
        }

        .bor-cor {
            /deep/ .el-step__icon {
                border-color: red;
            }
        }

        /deep/ .el-icon-close {
            color: red;

        }

        /deep/ .el-step__line {
            top: 5px;
            left: 9px;
        }
    }

    .title-text {
        font-size: 15px;
        color: #585353;
        font-weight: 600;
    }

}

.evaluate {
    margin-top: 10px;
    margin-left: 20px;


}

.box {
    margin-left: auto;
    margin-right: auto;
    width: 95%;
    height: 80px;
    border-radius: 10px;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        border-radius: 5px;
        /* 继承父元素的圆角 */
        padding: 1px;
        /* 边框宽度 */
        box-sizing: border-box;
        /* 使 padding 不影响实际大小 */
        background: linear-gradient(45deg, #5ecbff, #5a78ff, #64f4ff, #86efac);
        /* 渐变色 */
        -webkit-mask: linear-gradient(#84bdf3 0 0) content-box, linear-gradient(#82e7b1 0 0);
        /* 遮罩 */
        -webkit-mask-composite: destination-out;
        /* 将两个渐变叠加 */
        mask-composite: exclude;
        /* 将两个渐变叠加 */
    }

    .box-text {
        display: block;
        color: #999;
        font-size: 12px;
        padding-left: 10px;
        padding-top: 10px;
    }

    .box-bottom {
        padding: 0px 10px;
        position: absolute;
        bottom: 0px;
        display: flex;
        width: 100%;

        .left {
            width: 50%;
            flex: 1;

            span {
                background: #eff6ff;
                font-size: 12px;
                position: relative;
                // top: 0.2333rem;
            }

            .span-text {
                color: #0881fa;
            }

            .span-text2 {
                color: #c2c4c5;
            }
        }

        .right {
            flex: 1;
            text-align: right;

            img {
                width: 28px;
                height: 28px;

            }
        }
    }

}



.search-box {
    position: fixed;

    // bottom: 50px;
    width: 9.76667rem;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
    z-index: 99;
    background: #fff;
    padding-bottom: env(safe-area-inset-bottom);

    /deep/ .el-input__inner {
        z-index: 99;
        border: none;
        width: 98%;
        margin: 2px;

    }

    .btn {
        background-color: #fff;
        border: none;
        color: #1c6bf4;
    }

    .box-tishi {
        width: 9.24667rem;
        // height: 50px;
        margin-left: 10px;
        margin-right: auto;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid rgb(228, 231, 237);



        li {
            color: #606266;
            margin-bottom: 8px;
        }
    }



    .el-icon-caret-bottom {
        position: relative;
        top: -9px;
        margin-left: 20px;
        color: #dce1e1;
        font-size: 25px;
    }
}
</style>